#include "TwoThreeTreeFactory.h"
//You may add #include statements here

/*
	You will MODIFY THIS DOCUMENT.
*/
//=======================================================================================
/*
	getTwoThreeTree()

	Creates and returns an object whose class extends TwoTreeTreeInterface.
	This should be an object of a class you have created.

	Example: If you made a class called "TwoThreeTree", you might say, "return new TwoThreeTree();".

	This method should return NULL or 0 if you do not intent to do the extra credit
*/
TwoThreeTreeInterface * TwoThreeTreeFactory::getTwoThreeTree()
{
	return 0;//Modify this line
}
