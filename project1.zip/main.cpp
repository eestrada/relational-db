#include "Driver.h"

int main(int argc, char **argv)
{
    return Driver::lex(argc, argv);
}

