#ifndef __DRIVER_H__
#define __DRIVER_H__

namespace Driver
{

int lex(int argc, char **argv);
int parse(int argc, char **argv);
int interpret(int argc, char **argv);

}

#endif // End include guard
