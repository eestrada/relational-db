#if !defined(ASCII_CODES_H)
#define ASCII_CODES_H

#define ASCII_ESCAPE 0x1B
#define ASCII_LOWER_W 0x77
#define ASCII_LOWER_A 0x61
#define ASCII_LOWER_S 0x73
#define ASCII_LOWER_D 0x64
#define ASCII_LOWER_SPACE 0x20

#endif /* end include guard*/
