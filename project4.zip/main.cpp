#include "Driver.h"

int main(int argc, char **argv)
{
    return Driver::interpret(argc, argv);
}

