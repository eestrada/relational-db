#ifndef _HEADER_HPP_
#define _HEADER_HPP_

int var = 0;

#endif //_HEADER_HPP_
