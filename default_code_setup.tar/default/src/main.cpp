#include <iostream>
#include "header.hpp"

int main(void)
{
    std::cout << "This is the default program" << std::endl;
}
